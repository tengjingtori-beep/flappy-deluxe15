import SwiftUI

private func productEmoji(_ id: String) -> String {
    switch id {
    case "gold": return "👑"
    case "robot": return "🤖"
    case "rainbow": return "🌈"
    case "aurora": return "✨"
    case "coinpack": return "🪙"
    case "revivepack": return "💖"
    case "allpack": return "🎁"
    default: return "🎁"
    }
}

// MARK: - スキン＆テーマ
struct SkinThemeView: View {
    @ObservedObject var data = GameData.shared
    @Environment(\.presentationMode) var presentation
    @State private var message: String? = nil

    var body: some View {
        NavigationView {
            List {
                if let m = message { Text(m).foregroundColor(.green).bold() }
                Section(header: Text("🐤 鳥スキン（所持コイン \(data.coins) 枚）")) {
                    ForEach(allSkins) { skin in
                        HStack {
                            Circle().fill(skin.body).frame(width: 34, height: 34)
                                .overlay(Circle().stroke(Color.gray.opacity(0.4)))
                            VStack(alignment: .leading) {
                                Text(skin.name).bold()
                                Text(skin.detail).font(.caption).foregroundColor(.gray)
                            }
                            Spacer()
                            skinButton(skin)
                        }
                    }
                }
                Section(header: Text("🌈 テーマ")) {
                    ForEach(allThemes) { theme in
                        HStack {
                            RoundedRectangle(cornerRadius: 6)
                                .fill(LinearGradient(colors: [theme.top, theme.bottom], startPoint: .top, endPoint: .bottom))
                                .frame(width: 34, height: 34)
                            VStack(alignment: .leading) {
                                Text(theme.name).bold()
                                Text(theme.detail).font(.caption).foregroundColor(.gray)
                            }
                            Spacer()
                            themeButton(theme)
                        }
                    }
                }
                Section {
                    Text("✨マークはプレミアムです。「プレミアムお試し」から無料でお試し入手できます（本当のお金はかかりません）。")
                        .font(.caption).foregroundColor(.gray)
                }
            }
            .navigationTitle("スキン＆テーマ")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("閉じる") { presentation.wrappedValue.dismiss() } } }
        }
    }

    @ViewBuilder private func skinButton(_ skin: BirdSkin) -> some View {
        if data.ownedSkins.contains(skin.id) {
            Button(data.selectedSkin == skin.id ? "使用中" : "使う") {
                data.selectedSkin = skin.id; SoundManager.shared.click()
            }.disabled(data.selectedSkin == skin.id)
        } else if skin.premiumPrice > 0 {
            Text("✨¥\(skin.premiumPrice)").foregroundColor(.purple).bold()
        } else {
            Button("🪙\(skin.coinPrice)") {
                if data.coins >= skin.coinPrice {
                    data.coins -= skin.coinPrice
                    data.ownedSkins.append(skin.id)
                    data.selectedSkin = skin.id
                    SoundManager.shared.buy()
                    message = "\(skin.name) を買いました！"
                } else {
                    message = "コインが足りません（あと \(skin.coinPrice - data.coins) 枚）"
                }
            }.disabled(data.coins < skin.coinPrice)
        }
    }
    @ViewBuilder private func themeButton(_ theme: StageTheme) -> some View {
        if data.ownedThemes.contains(theme.id) {
            Button(data.selectedTheme == theme.id ? "使用中" : "使う") {
                data.selectedTheme = theme.id; SoundManager.shared.click()
            }.disabled(data.selectedTheme == theme.id)
        } else if theme.premiumPrice > 0 {
            Text("✨¥\(theme.premiumPrice)").foregroundColor(.purple).bold()
        } else {
            Button("🪙\(theme.coinPrice)") {
                if data.coins >= theme.coinPrice {
                    data.coins -= theme.coinPrice
                    data.ownedThemes.append(theme.id)
                    data.selectedTheme = theme.id
                    SoundManager.shared.buy()
                    message = "\(theme.name) を買いました！"
                } else {
                    message = "コインが足りません（あと \(theme.coinPrice - data.coins) 枚）"
                }
            }.disabled(data.coins < theme.coinPrice)
        }
    }
}

// MARK: - コインショップ（消耗品）
struct CoinShopView: View {
    @ObservedObject var data = GameData.shared
    @Environment(\.presentationMode) var presentation
    @State private var message: String? = nil

    var body: some View {
        NavigationView {
            List {
                if let m = message { Text(m).foregroundColor(.green).bold() }
                Section(header: Text("所持コイン \(data.coins) 枚")) {
                    HStack {
                        Text("💖 ふっかつ札"); Spacer()
                        Button("🪙30") {
                            if data.coins >= 30 { data.coins -= 30; data.reviveTickets += 1; SoundManager.shared.buy(); message = "ふっかつ札を買いました（所持 \(data.reviveTickets) 枚）" }
                        }.disabled(data.coins < 30)
                    }
                    Text("ゲームオーバー時に1回だけ復活できます").font(.caption).foregroundColor(.gray)
                    HStack {
                        Text("🎲 ランダムスキンの箱"); Spacer()
                        Button("🪙120") { openBox() }.disabled(data.coins < 120)
                    }
                    Text("まだ持っていないコインスキンの中からランダムで1つ当たります").font(.caption).foregroundColor(.gray)
                }
                Section(header: Text("コインの集め方")) {
                    Text("・ ゲーム中の金コインを取る（1枚＝1コイン）")
                    Text("・ 毎日のログインボーナス")
                    Text("・ 実績を達成する")
                    Text("・ プレミアムお試しのコインパック（無料）")
                }.font(.subheadline)
            }
            .navigationTitle("コインショップ")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("閉じる") { presentation.wrappedValue.dismiss() } } }
        }
    }
    private func openBox() {
        let candidates = allSkins.filter { $0.coinPrice > 0 && !data.ownedSkins.contains($0.id) }
        guard data.coins >= 120 else { return }
        data.coins -= 120
        if let pick = candidates.randomElement() {
            data.ownedSkins.append(pick.id)
            SoundManager.shared.buy()
            message = "🎉 \(pick.name) が当たりました！"
        } else {
            data.reviveTickets += 3
            message = "コインスキンは全部持っています！ 代わりにふっかつ札×3"
        }
    }
}

// MARK: - プレミアムお試し（見かけ課金・本当は無料）
struct TrialStoreView: View {
    @ObservedObject var data = GameData.shared
    @Environment(\.presentationMode) var presentation
    @State private var processingId: String? = nil
    @State private var doneMessage: String? = nil

    private func isRepeatable(_ p: TrialProduct) -> Bool { p.id == "coinpack" || p.id == "revivepack" }
    private func isOwned(_ p: TrialProduct) -> Bool {
        if isRepeatable(p) { return false }
        if p.id == "allpack" { return data.trialOwned.contains("gold") && data.trialOwned.contains("robot") && data.trialOwned.contains("rainbow") && data.trialOwned.contains("aurora") }
        return data.trialOwned.contains(p.id)
    }

    var body: some View {
        NavigationView {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("✨ プレミアムお試しショップ").bold()
                        Text("値段は「本物っぽく」表示しているだけです。お試しボタンを押すと無料で手に入ります。")
                        Text("⚠️ 本当のお金は一切かかりません。App Storeの課金も使いません。全部このゲームの中だけの遊びです。")
                            .bold().foregroundColor(.red)
                    }.font(.subheadline)
                }
                if let m = doneMessage { Text(m).foregroundColor(.green).bold() }
                Section(header: Text("アイテム")) {
                    ForEach(trialProducts) { p in
                        HStack {
                            Text(productEmoji(p.id)).font(.system(size: 30))
                            VStack(alignment: .leading) {
                                Text(p.name).bold()
                                Text(p.detail).font(.caption).foregroundColor(.gray)
                                Text("¥\(p.yen)").foregroundColor(.purple).bold()
                            }
                            Spacer()
                            if isOwned(p) {
                                Text("入手済み").foregroundColor(.gray).bold()
                            } else if processingId == p.id {
                                ProgressView()
                            } else {
                                Button("無料でお試し") { trialBuy(p) }
                                    .bold().foregroundColor(.white)
                                    .padding(.horizontal, 10).padding(.vertical, 7)
                                    .background(Color.purple).cornerRadius(9)
                            }
                        }
                    }
                }
                Section {
                    Button("🔄 購入の復元（お試し）") {
                        doneMessage = "復元しました（お試しなので元から全部この端末に保存されています）"
                        SoundManager.shared.buy()
                    }
                    Text("データは全部この端末の中に保存されます。ネットにも送りません。").font(.caption).foregroundColor(.gray)
                }
            }
            .navigationTitle("プレミアムお試し")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("閉じる") { presentation.wrappedValue.dismiss() } } }
        }
    }

    private func trialBuy(_ p: TrialProduct) {
        processingId = p.id
        SoundManager.shared.click()
        // 本物っぽい「処理中」の演出だけ（通信は一切しません）
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            data.grantTrialProduct(p)
            processingId = nil
            SoundManager.shared.buy()
            doneMessage = "🎉 お試し購入が完了しました！「\(p.name)」を手に入れました。お支払いは ¥0 です（本当のお金はかかっていません）"
        }
    }
}

// MARK: - 記録・実績
struct StatsView: View {
    @ObservedObject var data = GameData.shared
    @Environment(\.presentationMode) var presentation
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("📊 記録")) {
                    row("遊んだ回数", "\(data.totalGames) 回")
                    row("通った土管", "\(data.totalPipes) 本")
                    row("集めたコイン累計", "\(data.totalCoinsEarned) 枚")
                    row("取ったパワーアップ", "\(data.totalPowerups) 回")
                    row("復活した回数", "\(data.totalRevives) 回")
                    row("連続で遊んだ日数", "\(data.streak) 日")
                    ForEach(GameMode.allCases) { mode in
                        row("\(mode.title) ベスト", "\(data.best(for: mode)) 点")
                    }
                }
                Section(header: Text("🏅 実績（達成すると自動でコイン）")) {
                    ForEach(allAchievements) { a in
                        HStack {
                            Text(a.check(data) ? "✅" : "⬜")
                            VStack(alignment: .leading) {
                                Text(a.name).bold()
                                Text(a.detail).font(.caption).foregroundColor(.gray)
                            }
                            Spacer()
                            Text(data.claimedAchievements.contains(a.id) ? "受取済" : "🪙\(a.reward)")
                                .font(.caption).foregroundColor(.gray)
                        }
                    }
                }
            }
            .navigationTitle("記録・実績")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("閉じる") { presentation.wrappedValue.dismiss() } } }
        }
    }
    private func row(_ k: String, _ v: String) -> some View {
        HStack { Text(k); Spacer(); Text(v).bold() }
    }
}

// MARK: - 設定
struct SettingsView: View {
    @ObservedObject var data = GameData.shared
    @Environment(\.presentationMode) var presentation
    @State private var showReset = false
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("音と振動")) {
                    Toggle("効果音", isOn: $data.soundOn)
                    Toggle("BGM（かんたんな音楽）", isOn: $data.musicOn)
                        .onChange(of: data.musicOn) { on in if !on { SoundManager.shared.stopMusic() } }
                    Toggle("振動（バイブ）", isOn: $data.hapticsOn)
                }
                Section(header: Text("むずかしさ")) {
                    Picker("むずかしさ", selection: $data.difficulty) {
                        Text("やさしい").tag(0)
                        Text("ふつう").tag(1)
                        Text("むずかしい").tag(2)
                    }.pickerStyle(.segmented)
                    Text("やさしい：スキマ広め・ゆっくり／むずかしい：スキマ狭め・速い").font(.caption).foregroundColor(.gray)
                }
                Section(header: Text("データ")) {
                    Button("記録を全部消す", role: .destructive) { showReset = true }
                    Text("コイン・スキン・記録が全部最初の状態に戻ります").font(.caption).foregroundColor(.gray)
                }
                Section {
                    Text("フラッピーDX v1.0\niPhone 7 / iOS 15 対応・完全オフライン\n課金は全部「お試し」で、本当のお金はかかりません。")
                        .font(.caption).foregroundColor(.gray)
                }
            }
            .navigationTitle("設定")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("閉じる") { presentation.wrappedValue.dismiss() } } }
            .alert(isPresented: $showReset) {
                Alert(title: Text("本当に消しますか？"),
                      message: Text("コイン・スキン・記録が全部消えます"),
                      primaryButton: .destructive(Text("消す")) { resetAll() },
                      secondaryButton: .cancel(Text("やめる")))
            }
        }
    }
    private func resetAll() {
        let d = UserDefaults.standard
        for k in ["coins","ownedSkins","ownedThemes","selectedSkin","selectedTheme","reviveTickets","bestByMode","totalGames","totalCoinsEarned","totalPowerups","totalRevives","totalPipes","claimedAchievements","trialOwned","streak","lastPlayDay"] { d.removeObject(forKey: k) }
        data.coins = 0; data.ownedSkins = ["hiyoko"]; data.ownedThemes = ["sora"]
        data.selectedSkin = "hiyoko"; data.selectedTheme = "sora"
        data.reviveTickets = 0; data.bestByMode = [:]; data.totalGames = 0
        data.totalCoinsEarned = 0; data.totalPowerups = 0; data.totalRevives = 0
        data.totalPipes = 0; data.claimedAchievements = []; data.trialOwned = []; data.streak = 1
    }
}

// MARK: - あそびかた
struct HowToView: View {
    @Environment(\.presentationMode) var presentation
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("基本")) {
                    Text("👆 画面をタップすると羽ばたきます")
                    Text("🟩 土管のスキマを通ると +1点（⭐効果中は2点）")
                    Text("🪙 金コインを集めるとショップで使えます")
                    Text("💥 土管・地面・天井に当たるとゲームオーバー")
                }
                Section(header: Text("パワーアップ（取ると発動）")) {
                    Text("🛡️ シールド：1回だけ当たっても助かる")
                    Text("🐢 スロー：6秒ゆっくりになる")
                    Text("🧲 マグネット：6秒コインを引き寄せる")
                    Text("🤏 ちっちゃく：8秒 当たり判定が小さくなる")
                    Text("⭐ スコア2倍：10秒 点が2倍")
                }
                Section(header: Text("モード")) {
                    Text("逆重力：重力が逆。タップで下に進みます")
                    Text("今日のチャレンジ：毎日みんな同じコース（日替わり）")
                    Text("ナイト：真夜中の高速フライト")
                }
                Section(header: Text("お金について")) {
                    Text("このゲームの「課金」は全部お試しの遊びです。値段が書いてあっても、本当のお金は一切かかりません。安心して全部お試ししてください。")
                        .bold()
                    Text("ネット接続は使いません。データは全部この端末の中だけです。")
                }
            }
            .navigationTitle("あそびかた")
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("閉じる") { presentation.wrappedValue.dismiss() } } }
        }
    }
}
