import SwiftUI

struct ContentView: View {
    @ObservedObject var data = GameData.shared
    @State private var playingMode: GameMode? = nil
    @State private var showShop = false
    @State private var showTrialStore = false
    @State private var showStats = false
    @State private var showSettings = false
    @State private var showHowTo = false
    @State private var showSkins = false
    @State private var claimMessage: String? = nil

    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(colors: [data.currentTheme.top, data.currentTheme.bottom],
                               startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 16) {
                        Text("🐤").font(.system(size: 84))
                        Text("フラッピーDX")
                            .font(.system(size: 38, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                            .shadow(color: .black.opacity(0.35), radius: 3, y: 2)
                        Text("本家より盛りだくさん！ 6モード・スキン11種・テーマ7種")
                            .font(.subheadline).foregroundColor(.white.opacity(0.95))
                            .multilineTextAlignment(.center)

                        HStack(spacing: 14) {
                            Text("🪙 \(data.coins)")
                            Text("💖 ふっかつ札 \(data.reviveTickets)枚")
                            Text("🏆 最高 \(data.maxBest)点")
                        }
                        .font(.headline).foregroundColor(.white)
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .background(Color.black.opacity(0.25)).cornerRadius(12)

                        if let msg = data.dailyRewardMessage {
                            Text("🎁 \(msg)")
                                .font(.subheadline.bold()).foregroundColor(.yellow)
                                .padding(10).background(Color.black.opacity(0.3)).cornerRadius(10)
                        }

                        // モード選択
                        VStack(spacing: 10) {
                            ForEach(GameMode.allCases) { mode in
                                Button {
                                    SoundManager.shared.click()
                                    playingMode = mode
                                } label: {
                                    HStack {
                                        VStack(alignment: .leading, spacing: 2) {
                                            Text("▶ \(mode.title)").font(.headline)
                                            Text(mode.detail).font(.caption).opacity(0.85)
                                        }
                                        Spacer()
                                        Text("ベスト \(data.best(for: mode))")
                                            .font(.subheadline.bold())
                                    }
                                    .foregroundColor(.white)
                                    .padding(13)
                                    .background(mode == .daily ? Color.purple.opacity(0.85) : Color(red: 0.15, green: 0.6, blue: 0.3).opacity(0.92))
                                    .cornerRadius(14)
                                }
                            }
                        }

                        // サブメニュー
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                            menuButton("🎨 スキン＆テーマ") { showSkins = true }
                            menuButton("🛒 コインショップ") { showShop = true }
                            menuButton("✨ プレミアムお試し") { showTrialStore = true }
                            menuButton("📊 記録・実績") { showStats = true }
                            menuButton("❓ あそびかた") { showHowTo = true }
                            menuButton("⚙️ 設定") { showSettings = true }
                        }

                        if let msg = claimMessage {
                            Text(msg).font(.subheadline.bold()).foregroundColor(.yellow)
                        }
                        Text("完全オフライン対応：ネットなしで全部遊べます")
                            .font(.caption).foregroundColor(.white.opacity(0.8))
                            .padding(.bottom, 10)
                    }
                    .padding(16)
                }
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(.stack)
        .fullScreenCover(item: $playingMode) { mode in
            GameRepresentable(mode: mode) {
                playingMode = nil
                let gained = data.claimReadyAchievements()
                if gained > 0 { claimMessage = "🏅 実績ボーナス +\(gained)コイン もらいました！" }
            }
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showSkins) { SkinThemeView() }
        .sheet(isPresented: $showShop) { CoinShopView() }
        .sheet(isPresented: $showTrialStore) { TrialStoreView() }
        .sheet(isPresented: $showStats) { StatsView() }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showHowTo) { HowToView() }
    }

    private func menuButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button {
            SoundManager.shared.click()
            action()
        } label: {
            Text(title)
                .font(.headline).foregroundColor(.white)
                .frame(maxWidth: .infinity).padding(.vertical, 13)
                .background(Color.black.opacity(0.35)).cornerRadius(12)
        }
    }
}
