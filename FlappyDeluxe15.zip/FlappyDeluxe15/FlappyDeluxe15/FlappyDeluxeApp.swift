import SwiftUI

@main
struct FlappyDeluxeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
