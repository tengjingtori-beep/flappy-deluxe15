import SwiftUI
import UIKit

// MARK: - SwiftUI から呼ぶラッパー
struct GameRepresentable: UIViewControllerRepresentable {
    let mode: GameMode
    var onExit: () -> Void
    func makeUIViewController(context: Context) -> GameViewController {
        let vc = GameViewController(mode: mode)
        vc.onExit = onExit
        return vc
    }
    func updateUIViewController(_ uiViewController: GameViewController, context: Context) {}
}

// MARK: - 乱数（今日のチャレンジ用シード付き）
struct LCG {
    var state: UInt64
    mutating func next() -> Double {
        state = state &* 6364136223846793005 &+ 1442695040888963407
        return Double((state >> 33) & 0x7fffffff) / Double(0x7fffffff)
    }
}

enum PowerKind: CaseIterable {
    case shield, slow, magnet, tiny, doubleScore
    var emoji: String {
        switch self {
        case .shield: return "🛡️"
        case .slow: return "🐢"
        case .magnet: return "🧲"
        case .tiny: return "🤏"
        case .doubleScore: return "⭐"
        }
    }
    var name: String {
        switch self {
        case .shield: return "シールド（1回守る）"
        case .slow: return "スロー（6秒ゆっくり）"
        case .magnet: return "マグネット（6秒コイン吸着）"
        case .tiny: return "ちっちゃく（8秒当たり判定小）"
        case .doubleScore: return "スコア2倍（10秒）"
        }
    }
}

struct Pipe { var x: CGFloat; var gapY: CGFloat; var scored = false }
struct FieldCoin { var x: CGFloat; var y: CGFloat; var taken = false }
struct FieldPower { var x: CGFloat; var y: CGFloat; var kind: PowerKind; var taken = false }
struct Particle { var x: CGFloat; var y: CGFloat; var vx: CGFloat; var vy: CGFloat; var life: CGFloat; var color: UIColor }

enum PlayState { case ready, playing, paused, over }

// MARK: - ゲーム画面本体
final class GameViewController: UIViewController {
    let mode: GameMode
    var onExit: (() -> Void)?
    private let data = GameData.shared
    private let canvas = GameCanvasView()
    private var link: CADisplayLink?
    private var lastTime: CFTimeInterval = 0

    private(set) var state: PlayState = .ready
    // 物理
    var birdY: CGFloat = 300
    var birdVY: CGFloat = 0
    var birdX: CGFloat { view.bounds.width * 0.32 }
    var flapPhase: CGFloat = 0
    var pipes: [Pipe] = []
    var fieldCoins: [FieldCoin] = []
    var fieldPowers: [FieldPower] = []
    var particles: [Particle] = []
    private var spawnDistance: CGFloat = 0
    private var rng = LCG(state: UInt64(Date().timeIntervalSince1970))
    // スコア
    private var score = 0
    private var runCoins = 0
    private var runPipes = 0
    private var recorded = false
    private var recordedScore = 0
    private var recordedCoins = 0
    private var revivedThisRun = false
    // 効果
    var shield = false
    private var slowUntil: TimeInterval = 0
    private var magnetUntil: TimeInterval = 0
    var tinyUntil: TimeInterval = 0
    private var doubleUntil: TimeInterval = 0
    private var invincibleUntil: TimeInterval = 0
    var groundOffset: CGFloat = 0
    var elapsed: TimeInterval = 0

    // HUD
    private let scoreLabel = UILabel()
    private let coinLabel = UILabel()
    private let effectLabel = UILabel()
    private let pauseButton = UIButton(type: .system)
    private let centerPanel = UIView()
    private let panelTitle = UILabel()
    private let panelBody = UILabel()
    private let panelStack = UIStackView()

    init(mode: GameMode) {
        self.mode = mode
        super.init(nibName: nil, bundle: nil)
        if mode == .daily {
            let f = DateFormatter(); f.dateFormat = "yyyyMMdd"
            let seed = UInt64(f.string(from: Date())) ?? 1
            rng = LCG(state: seed &* 2654435761 &+ 97)
        }
    }
    required init?(coder: NSCoder) { fatalError() }

    var theme: StageTheme {
        if mode == .night { return allThemes.first { $0.id == "yoru" } ?? data.currentTheme }
        return data.currentTheme
    }
    var birdRadius: CGFloat { Date().timeIntervalSince1970 < tinyUntil ? 11 : 17 }
    private var now: TimeInterval { Date().timeIntervalSince1970 }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        canvas.frame = view.bounds
        canvas.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        canvas.engine = self
        view.addSubview(canvas)
        setupHUD()
        setupPanel()
        showReady()
        link = CADisplayLink(target: self, selector: #selector(tick(_:)))
        link?.add(to: .main, forMode: .common)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onTap))
        view.addGestureRecognizer(tap)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        link?.invalidate(); link = nil
        SoundManager.shared.stopMusic()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        birdY = view.bounds.height * 0.45
        if data.musicOn { SoundManager.shared.startMusic() }
    }

    private func setupHUD() {
        scoreLabel.font = .boldSystemFont(ofSize: 56)
        scoreLabel.textColor = .white
        scoreLabel.textAlignment = .center
        scoreLabel.shadowColor = UIColor.black.withAlphaComponent(0.45)
        scoreLabel.shadowOffset = CGSize(width: 0, height: 3)
        scoreLabel.text = "0"
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scoreLabel)
        coinLabel.font = .boldSystemFont(ofSize: 18)
        coinLabel.textColor = UIColor(red: 1, green: 0.85, blue: 0.2, alpha: 1)
        coinLabel.shadowColor = UIColor.black.withAlphaComponent(0.4)
        coinLabel.shadowOffset = CGSize(width: 0, height: 2)
        coinLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(coinLabel)
        effectLabel.font = .boldSystemFont(ofSize: 15)
        effectLabel.textColor = .white
        effectLabel.textAlignment = .center
        effectLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(effectLabel)
        pauseButton.setTitle("⏸", for: .normal)
        pauseButton.titleLabel?.font = .systemFont(ofSize: 26)
        pauseButton.addTarget(self, action: #selector(onPauseButton), for: .touchUpInside)
        pauseButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pauseButton)
        NSLayoutConstraint.activate([
            scoreLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            scoreLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            coinLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 14),
            coinLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            effectLabel.topAnchor.constraint(equalTo: scoreLabel.bottomAnchor, constant: 2),
            effectLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pauseButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 6),
            pauseButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -12),
        ])
        updateHUD()
    }

    private func setupPanel() {
        centerPanel.backgroundColor = UIColor.black.withAlphaComponent(0.72)
        centerPanel.layer.cornerRadius = 20
        centerPanel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(centerPanel)
        panelTitle.font = .boldSystemFont(ofSize: 28)
        panelTitle.textColor = .white
        panelTitle.textAlignment = .center
        panelTitle.numberOfLines = 0
        panelBody.font = .systemFont(ofSize: 16)
        panelBody.textColor = UIColor.white.withAlphaComponent(0.9)
        panelBody.textAlignment = .center
        panelBody.numberOfLines = 0
        panelStack.axis = .vertical
        panelStack.spacing = 10
        panelStack.translatesAutoresizingMaskIntoConstraints = false
        let v = UIStackView(arrangedSubviews: [panelTitle, panelBody, panelStack])
        v.axis = .vertical; v.spacing = 12
        v.translatesAutoresizingMaskIntoConstraints = false
        centerPanel.addSubview(v)
        NSLayoutConstraint.activate([
            centerPanel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            centerPanel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            centerPanel.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            centerPanel.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24),
            v.topAnchor.constraint(equalTo: centerPanel.topAnchor, constant: 20),
            v.bottomAnchor.constraint(equalTo: centerPanel.bottomAnchor, constant: -20),
            v.leadingAnchor.constraint(equalTo: centerPanel.leadingAnchor, constant: 20),
            v.trailingAnchor.constraint(equalTo: centerPanel.trailingAnchor, constant: -20),
        ])
    }

    private func makeButton(_ title: String, color: UIColor, action: Selector) -> UIButton {
        let b = UIButton(type: .system)
        b.setTitle(title, for: .normal)
        b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font = .boldSystemFont(ofSize: 18)
        b.backgroundColor = color
        b.layer.cornerRadius = 12
        b.contentEdgeInsets = UIEdgeInsets(top: 12, left: 18, bottom: 12, right: 18)
        b.addTarget(self, action: action, for: .touchUpInside)
        return b
    }
    private func clearPanelButtons() { panelStack.arrangedSubviews.forEach { $0.removeFromSuperview() } }

    private func showReady() {
        state = .ready
        centerPanel.isHidden = false
        panelTitle.text = mode.title
        panelBody.text = "\(mode.detail)\n\nタップで羽ばたきます。\n画面をタップしてスタート！\nベスト: \(data.best(for: mode))点"
        clearPanelButtons()
        panelStack.addArrangedSubview(makeButton("▶ スタート", color: UIColor(red: 0.2, green: 0.7, blue: 0.3, alpha: 1), action: #selector(startGame)))
        panelStack.addArrangedSubview(makeButton("ホームへもどる", color: .gray, action: #selector(goHome)))
    }

    @objc private func startGame() {
        score = 0; runCoins = 0; runPipes = 0; recorded = false; recordedScore = 0; recordedCoins = 0; revivedThisRun = false
        pipes.removeAll(); fieldCoins.removeAll(); fieldPowers.removeAll(); particles.removeAll()
        birdY = view.bounds.height * 0.45; birdVY = 0
        shield = false; slowUntil = 0; magnetUntil = 0; tinyUntil = 0; doubleUntil = 0
        spawnDistance = 120
        centerPanel.isHidden = true
        state = .playing
        flap()
        updateHUD()
    }

    @objc private func goHome() { onExit?() }

    @objc private func onPauseButton() {
        if state == .playing { pauseGame() }
    }
    private func pauseGame() {
        state = .paused
        centerPanel.isHidden = false
        panelTitle.text = "一時停止中"
        panelBody.text = "スコア \(score) 点"
        clearPanelButtons()
        panelStack.addArrangedSubview(makeButton("▶ つづける", color: UIColor(red: 0.2, green: 0.7, blue: 0.3, alpha: 1), action: #selector(resumeGame)))
        panelStack.addArrangedSubview(makeButton("↻ はじめから", color: .orange, action: #selector(startGame)))
        panelStack.addArrangedSubview(makeButton("ホームへもどる", color: .gray, action: #selector(goHome)))
    }
    @objc private func resumeGame() { centerPanel.isHidden = true; state = .playing }

    @objc private func onTap() {
        if state == .playing { flap() }
    }

    private func flap() {
        birdVY = (mode == .reverse) ? 460 : -460
        flapPhase = 1
        SoundManager.shared.flap()
        if data.hapticsOn { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    }

    // MARK: - ゲームループ
    @objc private func tick(_ link: CADisplayLink) {
        let dt = lastTime == 0 ? 0.016 : min(link.timestamp - lastTime, 0.05)
        lastTime = link.timestamp
        elapsed += dt
        flapPhase = max(0, flapPhase - CGFloat(dt) * 5)
        if state == .playing { update(dt: CGFloat(dt)) }
        updateParticles(dt: CGFloat(dt))
        canvas.setNeedsDisplay()
    }

    private func update(dt: CGFloat) {
        let h = view.bounds.height
        let groundH: CGFloat = 70
        var speed = mode.speed * 55 * data.difficultySpeedScale
        if now < slowUntil { speed *= 0.55 }
        groundOffset += speed * dt

        // 鳥の物理
        let gravity: CGFloat = (mode == .reverse) ? -1450 : 1450
        birdVY += gravity * dt
        birdVY = max(-620, min(760, birdVY))
        birdY += birdVY * dt

        // 土管の生成
        spawnDistance -= speed * dt
        if spawnDistance <= 0 {
            spawnDistance = 235
            let gap = 168 * mode.gapScale * data.difficultyGapScale
            let margin: CGFloat = 90
            let gy = margin + gap / 2 + CGFloat(rng.next()) * max(10, (h - groundH - margin * 2 - gap))
            pipes.append(Pipe(x: view.bounds.width + 40, gapY: gy))
            // コイン（スキマ付近に時々）
            if rng.next() < 0.55 {
                fieldCoins.append(FieldCoin(x: view.bounds.width + 40 + 35, y: gy + CGFloat(rng.next() - 0.5) * gap * 0.5))
            }
            // パワーアップ（時々・土管と土管の間）
            if rng.next() < 0.30 {
                let kinds = PowerKind.allCases
                let kind = kinds[Int(rng.next() * Double(kinds.count)) % kinds.count]
                fieldPowers.append(FieldPower(x: view.bounds.width + 40 + 140, y: 140 + CGFloat(rng.next()) * (h - groundH - 260), kind: kind))
            }
        }

        // 土管の移動とスコア
        for i in pipes.indices { pipes[i].x -= speed * dt }
        for i in pipes.indices where !pipes[i].scored && pipes[i].x + 70 < birdX {
            pipes[i].scored = true
            let gain = now < doubleUntil ? 2 : 1
            score += gain; runPipes += 1
            SoundManager.shared.score()
            updateHUD()
        }
        pipes.removeAll { $0.x < -90 }

        // コイン
        for i in fieldCoins.indices {
            fieldCoins[i].x -= speed * dt
            if now < magnetUntil {
                let dx = birdX - fieldCoins[i].x, dy = birdY - fieldCoins[i].y
                let dist = sqrt(dx * dx + dy * dy)
                if dist < 130 { fieldCoins[i].x += dx * dt * 6; fieldCoins[i].y += dy * dt * 6 }
            }
            if !fieldCoins[i].taken {
                let dx = birdX - fieldCoins[i].x, dy = birdY - fieldCoins[i].y
                if dx * dx + dy * dy < 32 * 32 {
                    fieldCoins[i].taken = true
                    runCoins += 1
                    SoundManager.shared.coin()
                    burst(x: fieldCoins[i].x, y: fieldCoins[i].y, color: UIColor(red: 1, green: 0.85, blue: 0.2, alpha: 1), count: 6)
                    updateHUD()
                }
            }
        }
        fieldCoins.removeAll { $0.taken || $0.x < -40 }

        // パワーアップ
        for i in fieldPowers.indices {
            fieldPowers[i].x -= speed * dt
            if !fieldPowers[i].taken {
                let dx = birdX - fieldPowers[i].x, dy = birdY - fieldPowers[i].y
                if dx * dx + dy * dy < 36 * 36 {
                    fieldPowers[i].taken = true
                    applyPower(fieldPowers[i].kind)
                }
            }
        }
        fieldPowers.removeAll { $0.taken || $0.x < -40 }

        // 当たり判定
        if now >= invincibleUntil {
            if birdY - birdRadius < 0 || birdY + birdRadius > h - groundH { crash(); return }
            let gap = 168 * mode.gapScale * data.difficultyGapScale
            for p in pipes {
                if birdX + birdRadius > p.x && birdX - birdRadius < p.x + 70 {
                    if birdY - birdRadius < p.gapY - gap / 2 || birdY + birdRadius > p.gapY + gap / 2 { crash(); return }
                }
            }
        }
    }

    private func applyPower(_ kind: PowerKind) {
        data.totalPowerups += 1
        SoundManager.shared.power()
        switch kind {
        case .shield: shield = true
        case .slow: slowUntil = now + 6
        case .magnet: magnetUntil = now + 6
        case .tiny: tinyUntil = now + 8
        case .doubleScore: doubleUntil = now + 10
        }
        burst(x: birdX, y: birdY, color: .cyan, count: 10)
        updateHUD()
        effectFlash(kind.name)
    }
    private func effectFlash(_ text: String) {
        effectLabel.text = text
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { [weak self] in
            if self?.effectLabel.text == text { self?.refreshEffectLabel() }
        }
    }
    private func refreshEffectLabel() {
        var parts: [String] = []
        if shield { parts.append("🛡️シールド") }
        if now < slowUntil { parts.append("🐢スロー") }
        if now < magnetUntil { parts.append("🧲マグネット") }
        if now < tinyUntil { parts.append("🤏小型化") }
        if now < doubleUntil { parts.append("⭐2倍") }
        effectLabel.text = parts.joined(separator: " ")
    }

    private func crash() {
        if shield {
            shield = false
            invincibleUntil = now + 2
            pipes.removeAll { abs($0.x - birdX) < 130 }
            birdY = min(max(birdY, 80), view.bounds.height - 160)
            birdVY = 0
            SoundManager.shared.power()
            effectFlash("シールドで助かった！")
            updateHUD()
            return
        }
        state = .over
        SoundManager.shared.hit()
        SoundManager.shared.die()
        if data.hapticsOn { UINotificationFeedbackGenerator().notificationOccurred(.error) }
        burst(x: birdX, y: birdY, color: UIColor(data.currentSkin.body), count: 18)
        if !recorded {
            recorded = true
            recordedScore = score; recordedCoins = runCoins
            data.recordGame(mode: mode, score: score, coinsEarned: runCoins, pipes: runPipes)
        } else {
            // 復活後の2回目の記録：ベストと増えたコインだけ反映
            if score > data.best(for: mode) { data.bestByMode[mode.rawValue] = score }
            let extra = runCoins - recordedCoins
            if extra > 0 { data.coins += extra; data.totalCoinsEarned += extra; recordedCoins = runCoins }
        }
        showGameOver()
    }

    private func medal(for s: Int) -> String {
        if s >= 40 { return "💎 プラチナメダル！" }
        if s >= 30 { return "🥇 金メダル！" }
        if s >= 20 { return "🥈 銀メダル！" }
        if s >= 10 { return "🥉 銅メダル！" }
        return "メダルまであと少し！"
    }

    private func showGameOver() {
        centerPanel.isHidden = false
        let isBest = score >= data.best(for: mode) && score > 0
        panelTitle.text = "ゲームオーバー"
        panelBody.text = "スコア \(score) 点　ベスト \(data.best(for: mode)) 点\(isBest ? " 🎉新記録！" : "")\n\(medal(for: score))\nコイン +\(runCoins) 枚"
        clearPanelButtons()
        if !revivedThisRun && data.reviveTickets > 0 {
            panelStack.addArrangedSubview(makeButton("💖 ふっかつ札で復活（残り\(data.reviveTickets)枚）", color: .systemPink, action: #selector(reviveWithTicket)))
        }
        if !revivedThisRun && data.coins >= 50 {
            panelStack.addArrangedSubview(makeButton("🪙 50コインで復活", color: .systemPurple, action: #selector(reviveWithCoins)))
        }
        panelStack.addArrangedSubview(makeButton("↻ もう一回", color: UIColor(red: 0.2, green: 0.7, blue: 0.3, alpha: 1), action: #selector(startGame)))
        panelStack.addArrangedSubview(makeButton("ホームへもどる", color: .gray, action: #selector(goHome)))
    }

    @objc private func reviveWithTicket() {
        guard data.reviveTickets > 0 else { return }
        data.reviveTickets -= 1
        doRevive()
    }
    @objc private func reviveWithCoins() {
        guard data.coins >= 50 else { return }
        data.coins -= 50
        doRevive()
    }
    private func doRevive() {
        revivedThisRun = true
        data.totalRevives += 1
        pipes.removeAll { $0.x > birdX - 60 }
        birdY = view.bounds.height * 0.45
        birdVY = 0
        invincibleUntil = now + 2.5
        centerPanel.isHidden = true
        state = .playing
        SoundManager.shared.buy()
    }

    private func burst(x: CGFloat, y: CGFloat, color: UIColor, count: Int) {
        for _ in 0..<count {
            particles.append(Particle(x: x, y: y,
                vx: CGFloat(rng.next() - 0.5) * 260, vy: CGFloat(rng.next() - 0.5) * 260,
                life: 0.6, color: color))
        }
    }
    private func updateParticles(dt: CGFloat) {
        for i in particles.indices {
            particles[i].x += particles[i].vx * dt
            particles[i].y += particles[i].vy * dt
            particles[i].vy += 300 * dt
            particles[i].life -= dt
        }
        particles.removeAll { $0.life <= 0 }
    }

    private func updateHUD() {
        scoreLabel.text = "\(score)"
        coinLabel.text = "🪙 \(runCoins)（所持 \(data.coins)）"
        refreshEffectLabel()
    }
}

// MARK: - 描画キャンバス
final class GameCanvasView: UIView {
    weak var engine: GameViewController?
    private var stars: [(CGFloat, CGFloat, CGFloat)] = []
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        var r = LCG(state: 12345)
        for _ in 0..<70 { stars.append((CGFloat(r.next()), CGFloat(r.next()), CGFloat(1 + r.next() * 2))) }
    }
    required init?(coder: NSCoder) { fatalError() }

    override func draw(_ rect: CGRect) {
        guard let e = engine, let ctx = UIGraphicsGetCurrentContext() else { return }
        let theme = e.theme
        let data = GameData.shared
        let w = bounds.width, h = bounds.height
        let groundH: CGFloat = 70

        // 空のグラデーション
        let colors = [UIColor(theme.top).cgColor, UIColor(theme.bottom).cgColor] as CFArray
        if let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
            ctx.drawLinearGradient(grad, start: CGPoint(x: 0, y: 0), end: CGPoint(x: 0, y: h), options: [])
        }
        // 星（夜系テーマ）
        if ["yoru", "uchu", "aurora"].contains(theme.id) || e.mode == .night {
            ctx.setFillColor(UIColor.white.cgColor)
            for (i, s) in stars.enumerated() {
                let tw = 0.5 + 0.5 * sin(CGFloat(e.elapsed) * 2 + CGFloat(i))
                ctx.setAlpha(0.4 + 0.6 * tw)
                ctx.fillEllipse(in: CGRect(x: s.0 * w, y: s.1 * (h - groundH - 60), width: s.2, height: s.2))
            }
            ctx.setAlpha(1)
            // 月
            ctx.setFillColor(UIColor(red: 0.98, green: 0.95, blue: 0.8, alpha: 1).cgColor)
            ctx.fillEllipse(in: CGRect(x: w - 90, y: 60, width: 46, height: 46))
        }
        // 雲（昼系）
        if ["sora", "yuyake", "sakura"].contains(theme.id) {
            ctx.setFillColor(UIColor.white.withAlphaComponent(0.75).cgColor)
            for i in 0..<5 {
                let cx = (CGFloat(i) * 190 - e.groundOffset * 0.3).truncatingRemainder(dividingBy: w + 160) - 80
                let x = cx < -80 ? cx + w + 160 : cx
                let y = 50 + CGFloat(i % 3) * 55
                ctx.fillEllipse(in: CGRect(x: x, y: y, width: 74, height: 30))
                ctx.fillEllipse(in: CGRect(x: x + 24, y: y - 12, width: 48, height: 30))
            }
        }
        // 桜の花びら / 海の泡
        if theme.id == "sakura" || theme.id == "umi" {
            ctx.setFillColor((theme.id == "sakura" ? UIColor(red: 1, green: 0.6, blue: 0.75, alpha: 0.8) : UIColor.white.withAlphaComponent(0.5)).cgColor)
            for i in 0..<14 {
                let speed: CGFloat = theme.id == "sakura" ? 26 : -18
                let px = (CGFloat(i * 67) + CGFloat(e.elapsed) * speed * 0.4).truncatingRemainder(dividingBy: w)
                let py = (CGFloat(i * 89) + CGFloat(e.elapsed) * abs(speed)).truncatingRemainder(dividingBy: max(1, h - groundH))
                ctx.fillEllipse(in: CGRect(x: px, y: theme.id == "umi" ? (h - groundH - py) : py, width: 7, height: 5))
            }
        }

        let gap = 168 * e.mode.gapScale * data.difficultyGapScale
        // 土管
        let pipeColor = UIColor(theme.pipe)
        for p in e.pipes {
            drawPipe(ctx: ctx, x: p.x, y: 0, width: 70, height: p.gapY - gap / 2, isTop: true, color: pipeColor)
            drawPipe(ctx: ctx, x: p.x, y: p.gapY + gap / 2, width: 70, height: h - groundH - (p.gapY + gap / 2), isTop: false, color: pipeColor)
        }
        // コイン
        for c in e.fieldCoins {
            ctx.setFillColor(UIColor(red: 1, green: 0.82, blue: 0.15, alpha: 1).cgColor)
            ctx.fillEllipse(in: CGRect(x: c.x - 13, y: c.y - 13, width: 26, height: 26))
            ctx.setStrokeColor(UIColor(red: 0.8, green: 0.58, blue: 0, alpha: 1).cgColor)
            ctx.setLineWidth(2.5)
            ctx.strokeEllipse(in: CGRect(x: c.x - 13, y: c.y - 13, width: 26, height: 26))
            ctx.setFillColor(UIColor(red: 0.85, green: 0.62, blue: 0, alpha: 1).cgColor)
            ctx.fillEllipse(in: CGRect(x: c.x - 6, y: c.y - 6, width: 12, height: 12))
        }
        // パワーアップ
        for p in e.fieldPowers {
            ctx.setFillColor(UIColor.white.withAlphaComponent(0.92).cgColor)
            ctx.fillEllipse(in: CGRect(x: p.x - 19, y: p.y - 19, width: 38, height: 38))
            ctx.setStrokeColor(UIColor.systemPurple.cgColor); ctx.setLineWidth(2.5)
            ctx.strokeEllipse(in: CGRect(x: p.x - 19, y: p.y - 19, width: 38, height: 38))
            let s = p.kind.emoji as NSString
            s.draw(at: CGPoint(x: p.x - 13, y: p.y - 13), withAttributes: [.font: UIFont.systemFont(ofSize: 22)])
        }
        // パーティクル
        for pt in e.particles {
            ctx.setFillColor(pt.color.withAlphaComponent(max(0, min(1, pt.life * 1.6))).cgColor)
            ctx.fillEllipse(in: CGRect(x: pt.x - 4, y: pt.y - 4, width: 8, height: 8))
        }
        // 地面
        ctx.setFillColor(UIColor(red: 0.45, green: 0.32, blue: 0.18, alpha: 1).cgColor)
        ctx.fill(CGRect(x: 0, y: h - groundH, width: w, height: groundH))
        ctx.setFillColor(UIColor(red: 0.35, green: 0.72, blue: 0.3, alpha: 1).cgColor)
        ctx.fill(CGRect(x: 0, y: h - groundH, width: w, height: 16))
        ctx.setFillColor(UIColor(red: 0.3, green: 0.6, blue: 0.25, alpha: 1).cgColor)
        var gx = -e.groundOffset.truncatingRemainder(dividingBy: 36)
        while gx < w { ctx.fill(CGRect(x: gx, y: h - groundH, width: 18, height: 16)); gx += 36 }

        drawBird(ctx: ctx, e: e)
    }

    private func drawPipe(ctx: CGContext, x: CGFloat, y: CGFloat, width: CGFloat, height: CGFloat, isTop: Bool, color: UIColor) {
        guard height > 0 else { return }
        ctx.setFillColor(color.cgColor)
        ctx.fill(CGRect(x: x + 3, y: y, width: width - 6, height: height))
        let capY = isTop ? y + height - 26 : y
        ctx.fill(CGRect(x: x, y: capY, width: width, height: 26))
        ctx.setStrokeColor(color.withAlphaComponent(0.65).cgColor)
        ctx.setLineWidth(2)
        ctx.stroke(CGRect(x: x, y: capY, width: width, height: 26))
        ctx.setFillColor(UIColor.white.withAlphaComponent(0.18).cgColor)
        ctx.fill(CGRect(x: x + 10, y: y, width: 9, height: height))
    }

    private func drawBird(ctx: CGContext, e: GameViewController) {
        let data = GameData.shared
        let skin = data.currentSkin
        var body = UIColor(skin.body)
        if skin.id == "rainbow" {
            body = UIColor(hue: CGFloat(e.elapsed.truncatingRemainder(dividingBy: 3) / 3), saturation: 0.75, brightness: 0.95, alpha: 1)
        }
        let r = e.birdRadius
        ctx.saveGState()
        ctx.translateBy(x: e.birdX, y: e.birdY)
        let tilt = max(-0.45, min(0.85, e.birdVY / 700))
        ctx.rotate(by: e.mode == .reverse ? -tilt : tilt)
        if skin.id == "yurei" { ctx.setAlpha(0.75) }
        if e.shield {
            ctx.setStrokeColor(UIColor.cyan.cgColor); ctx.setLineWidth(3)
            ctx.strokeEllipse(in: CGRect(x: -r - 9, y: -r - 9, width: (r + 9) * 2, height: (r + 9) * 2))
        }
        // 体
        ctx.setFillColor(body.cgColor)
        ctx.fillEllipse(in: CGRect(x: -r, y: -r, width: r * 2, height: r * 2))
        // おなか
        ctx.setFillColor(UIColor.white.withAlphaComponent(0.55).cgColor)
        ctx.fillEllipse(in: CGRect(x: -r * 0.55, y: r * 0.15, width: r * 1.1, height: r * 0.7))
        // 羽（はばたき）
        let flap = sin(CGFloat(e.elapsed) * (10 + e.flapPhase * 22)) * r * 0.35
        ctx.setFillColor(UIColor(skin.wing).cgColor)
        ctx.fillEllipse(in: CGRect(x: -r * 0.85, y: -r * 0.15 + flap * 0.4, width: r * 1.05, height: r * 0.62))
        // ロボとりのアンテナ
        if skin.id == "robot" {
            ctx.setStrokeColor(UIColor.darkGray.cgColor); ctx.setLineWidth(2.5)
            ctx.move(to: CGPoint(x: 0, y: -r)); ctx.addLine(to: CGPoint(x: 0, y: -r - 11)); ctx.strokePath()
            ctx.setFillColor(UIColor.red.cgColor)
            ctx.fillEllipse(in: CGRect(x: -4, y: -r - 16, width: 8, height: 8))
        }
        // にんじゃのはちまき
        if skin.id == "ninja" {
            ctx.setFillColor(UIColor.red.cgColor)
            ctx.fill(CGRect(x: -r, y: -r * 0.55, width: r * 2, height: r * 0.34))
        }
        // 目
        ctx.setFillColor(UIColor.white.cgColor)
        ctx.fillEllipse(in: CGRect(x: r * 0.18, y: -r * 0.52, width: r * 0.62, height: r * 0.62))
        ctx.setFillColor(UIColor.black.cgColor)
        ctx.fillEllipse(in: CGRect(x: r * 0.42, y: -r * 0.34, width: r * 0.3, height: r * 0.3))
        // くちばし
        ctx.setFillColor(UIColor(skin.beak).cgColor)
        let beak = CGMutablePath()
        beak.move(to: CGPoint(x: r * 0.72, y: -r * 0.08))
        beak.addLine(to: CGPoint(x: r * 1.35, y: r * 0.08))
        beak.addLine(to: CGPoint(x: r * 0.72, y: r * 0.3))
        beak.closeSubpath()
        ctx.addPath(beak); ctx.fillPath()
        ctx.restoreGState()
    }
}
