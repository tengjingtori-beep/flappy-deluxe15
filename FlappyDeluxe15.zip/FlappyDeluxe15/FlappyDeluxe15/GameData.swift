import Foundation
import SwiftUI

// MARK: - ゲームモード
enum GameMode: String, CaseIterable, Identifiable {
    case normal, speedy, zen, reverse, night, daily
    var id: String { rawValue }
    var title: String {
        switch self {
        case .normal: return "ノーマル"
        case .speedy: return "スピード"
        case .zen: return "ゆったり"
        case .reverse: return "逆重力"
        case .night: return "ナイト"
        case .daily: return "今日のチャレンジ"
        }
    }
    var detail: String {
        switch self {
        case .normal: return "いつもの速さ"
        case .speedy: return "速い！ スコア効率アップ"
        case .zen: return "遅くてスキマ広め。練習に"
        case .reverse: return "重力が逆！タップで下降"
        case .night: return "真夜中の高速フライト"
        case .daily: return "日替わりで同じコース。毎日挑戦"
        }
    }
    var speed: CGFloat {
        switch self {
        case .zen: return 2.1
        case .speedy: return 4.7
        case .night: return 3.6
        default: return 3.1
        }
    }
    var gapScale: CGFloat {
        switch self {
        case .zen: return 1.28
        case .speedy: return 0.94
        default: return 1.0
        }
    }
}

// MARK: - 鳥スキン
struct BirdSkin: Identifiable, Equatable {
    let id: String
    let name: String
    let coinPrice: Int        // 0 = 最初から所持 or プレミアム
    let premiumPrice: Int     // 0 = プレミアムではない。円表示だけ（実際は無料お試し）
    let body: Color
    let wing: Color
    let beak: Color
    let detail: String
}

struct StageTheme: Identifiable, Equatable {
    let id: String
    let name: String
    let coinPrice: Int
    let premiumPrice: Int
    let top: Color
    let bottom: Color
    let pipe: Color
    let detail: String
}

// MARK: - お試し課金アイテム（本当のお金は一切かかりません）
struct TrialProduct: Identifiable {
    let id: String
    let name: String
    let yen: Int
    let detail: String
    let icon: String
}

let allSkins: [BirdSkin] = [
    BirdSkin(id: "hiyoko", name: "ひよこ", coinPrice: 0, premiumPrice: 0, body: .yellow, wing: .orange, beak: .orange, detail: "最初のパートナー"),
    BirdSkin(id: "aka", name: "あかとり", coinPrice: 50, premiumPrice: 0, body: .red, wing: .pink, beak: .yellow, detail: "情熱の赤"),
    BirdSkin(id: "ao", name: "あおとり", coinPrice: 80, premiumPrice: 0, body: .blue, wing: .cyan, beak: .orange, detail: "空色クール"),
    BirdSkin(id: "midori", name: "みどりとり", coinPrice: 100, premiumPrice: 0, body: .green, wing: .mint, beak: .yellow, detail: "森の色"),
    BirdSkin(id: "sakura", name: "さくらとり", coinPrice: 150, premiumPrice: 0, body: .pink, wing: .white, beak: .red, detail: "春のかわいさ"),
    BirdSkin(id: "panda", name: "パンダとり", coinPrice: 180, premiumPrice: 0, body: .white, wing: .black, beak: .black, detail: "白黒もこもこ"),
    BirdSkin(id: "ninja", name: "にんじゃとり", coinPrice: 220, premiumPrice: 0, body: Color(red: 0.15, green: 0.15, blue: 0.2), wing: .gray, beak: .yellow, detail: "影の達人"),
    BirdSkin(id: "yurei", name: "ゆうれいとり", coinPrice: 300, premiumPrice: 0, body: Color(white: 0.95, opacity: 0.75), wing: Color(white: 0.85, opacity: 0.7), beak: .gray, detail: "半透明でレア"),
    BirdSkin(id: "gold", name: "黄金とり", coinPrice: 0, premiumPrice: 480, body: Color(red: 1.0, green: 0.78, blue: 0.15), wing: Color(red: 1.0, green: 0.6, blue: 0.05), beak: .red, detail: "プレミアム：キラキラ黄金"),
    BirdSkin(id: "robot", name: "ロボとり", coinPrice: 0, premiumPrice: 680, body: .gray, wing: .blue, beak: .orange, detail: "プレミアム：メカ羽ばたき"),
    BirdSkin(id: "rainbow", name: "にじとり", coinPrice: 0, premiumPrice: 980, body: .purple, wing: .cyan, beak: .yellow, detail: "プレミアム：色が変わる伝説の鳥"),
]

let allThemes: [StageTheme] = [
    StageTheme(id: "sora", name: "青空", coinPrice: 0, premiumPrice: 0, top: Color(red: 0.3, green: 0.65, blue: 0.95), bottom: Color(red: 0.75, green: 0.9, blue: 1.0), pipe: .green, detail: "昼の空"),
    StageTheme(id: "yuyake", name: "夕焼け", coinPrice: 80, premiumPrice: 0, top: Color(red: 0.95, green: 0.45, blue: 0.25), bottom: Color(red: 1.0, green: 0.8, blue: 0.45), pipe: Color(red: 0.55, green: 0.3, blue: 0.45), detail: "オレンジの空"),
    StageTheme(id: "yoru", name: "星空", coinPrice: 120, premiumPrice: 0, top: Color(red: 0.03, green: 0.05, blue: 0.18), bottom: Color(red: 0.15, green: 0.2, blue: 0.45), pipe: Color(red: 0.25, green: 0.3, blue: 0.6), detail: "星がまたたく夜"),
    StageTheme(id: "umi", name: "海の中", coinPrice: 150, premiumPrice: 0, top: Color(red: 0.05, green: 0.45, blue: 0.65), bottom: Color(red: 0.4, green: 0.85, blue: 0.9), pipe: Color(red: 0.1, green: 0.55, blue: 0.45), detail: "泡がゆらゆら"),
    StageTheme(id: "sakura", name: "桜", coinPrice: 180, premiumPrice: 0, top: Color(red: 1.0, green: 0.75, blue: 0.85), bottom: Color(red: 1.0, green: 0.92, blue: 0.95), pipe: Color(red: 0.65, green: 0.4, blue: 0.3), detail: "花びら舞う春"),
    StageTheme(id: "uchu", name: "宇宙", coinPrice: 220, premiumPrice: 0, top: Color(red: 0.05, green: 0.02, blue: 0.12), bottom: Color(red: 0.3, green: 0.1, blue: 0.45), pipe: Color(red: 0.45, green: 0.4, blue: 0.7), detail: "無重力っぽい星空"),
    StageTheme(id: "aurora", name: "オーロラ", coinPrice: 0, premiumPrice: 580, top: Color(red: 0.02, green: 0.15, blue: 0.25), bottom: Color(red: 0.1, green: 0.55, blue: 0.45), pipe: Color(red: 0.15, green: 0.6, blue: 0.5), detail: "プレミアム：光のカーテン"),
]

let trialProducts: [TrialProduct] = [
    TrialProduct(id: "gold", name: "黄金とり スキン", yen: 480, detail: "キラキラ光るプレミアム鳥", icon: "crown.fill"),
    TrialProduct(id: "robot", name: "ロボとり スキン", yen: 680, detail: "メカメカしいプレミアム鳥", icon: "gearshape.2.fill"),
    TrialProduct(id: "rainbow", name: "にじとり スキン", yen: 980, detail: "色が変わり続ける伝説の鳥", icon: "rainbow"),
    TrialProduct(id: "aurora", name: "オーロラ テーマ", yen: 580, detail: "プレミアム背景テーマ", icon: "sparkles"),
    TrialProduct(id: "coinpack", name: "コイン 1000枚パック", yen: 320, detail: "ショップで使えるコインがどっさり", icon: "coins"),
    TrialProduct(id: "revivepack", name: "ふっかつ札 ×5", yen: 250, detail: "ゲームオーバーから復活できる札", icon: "heart.circle.fill"),
    TrialProduct(id: "allpack", name: "全部入りパック", yen: 1480, detail: "プレミアム全部＋コイン2000枚＋ふっかつ札10", icon: "gift.fill"),
]

// MARK: - 実績
struct Achievement: Identifiable {
    let id: String
    let name: String
    let detail: String
    let reward: Int
    let check: (GameData) -> Bool
}

let allAchievements: [Achievement] = [
    Achievement(id: "score10", name: "10点とった！", detail: "どれかのモードで10点", reward: 30) { $0.maxBest >= 10 },
    Achievement(id: "score25", name: "25点の壁", detail: "どれかのモードで25点", reward: 80) { $0.maxBest >= 25 },
    Achievement(id: "score50", name: "伝説の50点", detail: "どれかのモードで50点", reward: 200) { $0.maxBest >= 50 },
    Achievement(id: "games10", name: "10回チャレンジ", detail: "合計10ゲーム遊ぶ", reward: 30) { $0.totalGames >= 10 },
    Achievement(id: "games50", name: "常連さん", detail: "合計50ゲーム遊ぶ", reward: 100) { $0.totalGames >= 50 },
    Achievement(id: "coins100", name: "コイン集め名人", detail: "累計100コイン集める", reward: 50) { $0.totalCoinsEarned >= 100 },
    Achievement(id: "coins500", name: "大金持ち", detail: "累計500コイン集める", reward: 150) { $0.totalCoinsEarned >= 500 },
    Achievement(id: "streak3", name: "3日連続", detail: "3日連続で遊ぶ", reward: 60) { $0.streak >= 3 },
    Achievement(id: "revive1", name: "不死鳥", detail: "ふっかつを1回使う", reward: 40) { $0.totalRevives >= 1 },
    Achievement(id: "power5", name: "アイテム好き", detail: "パワーアップを5回取る", reward: 40) { $0.totalPowerups >= 5 },
]

// MARK: - 保存データ（全部オフライン・端末内だけ）
final class GameData: ObservableObject {
    static let shared = GameData()
    private let d = UserDefaults.standard

    @Published var coins: Int { didSet { d.set(coins, forKey: "coins") } }
    @Published var ownedSkins: [String] { didSet { d.set(ownedSkins, forKey: "ownedSkins") } }
    @Published var ownedThemes: [String] { didSet { d.set(ownedThemes, forKey: "ownedThemes") } }
    @Published var selectedSkin: String { didSet { d.set(selectedSkin, forKey: "selectedSkin") } }
    @Published var selectedTheme: String { didSet { d.set(selectedTheme, forKey: "selectedTheme") } }
    @Published var reviveTickets: Int { didSet { d.set(reviveTickets, forKey: "reviveTickets") } }
    @Published var bestByMode: [String: Int] { didSet { d.set(bestByMode, forKey: "bestByMode") } }
    @Published var totalGames: Int { didSet { d.set(totalGames, forKey: "totalGames") } }
    @Published var totalCoinsEarned: Int { didSet { d.set(totalCoinsEarned, forKey: "totalCoinsEarned") } }
    @Published var totalPowerups: Int { didSet { d.set(totalPowerups, forKey: "totalPowerups") } }
    @Published var totalRevives: Int { didSet { d.set(totalRevives, forKey: "totalRevives") } }
    @Published var totalPipes: Int { didSet { d.set(totalPipes, forKey: "totalPipes") } }
    @Published var claimedAchievements: [String] { didSet { d.set(claimedAchievements, forKey: "claimedAchievements") } }
    @Published var trialOwned: [String] { didSet { d.set(trialOwned, forKey: "trialOwned") } }
    @Published var streak: Int { didSet { d.set(streak, forKey: "streak") } }
    @Published var soundOn: Bool { didSet { d.set(soundOn, forKey: "soundOn") } }
    @Published var musicOn: Bool { didSet { d.set(musicOn, forKey: "musicOn") } }
    @Published var hapticsOn: Bool { didSet { d.set(hapticsOn, forKey: "hapticsOn") } }
    @Published var difficulty: Int { didSet { d.set(difficulty, forKey: "difficulty") } } // 0=やさしい 1=ふつう 2=むずかしい

    init() {
        coins = d.integer(forKey: "coins")
        ownedSkins = d.stringArray(forKey: "ownedSkins") ?? ["hiyoko"]
        ownedThemes = d.stringArray(forKey: "ownedThemes") ?? ["sora"]
        selectedSkin = d.string(forKey: "selectedSkin") ?? "hiyoko"
        selectedTheme = d.string(forKey: "selectedTheme") ?? "sora"
        reviveTickets = d.integer(forKey: "reviveTickets")
        bestByMode = (d.dictionary(forKey: "bestByMode") as? [String: Int]) ?? [:]
        totalGames = d.integer(forKey: "totalGames")
        totalCoinsEarned = d.integer(forKey: "totalCoinsEarned")
        totalPowerups = d.integer(forKey: "totalPowerups")
        totalRevives = d.integer(forKey: "totalRevives")
        totalPipes = d.integer(forKey: "totalPipes")
        claimedAchievements = d.stringArray(forKey: "claimedAchievements") ?? []
        trialOwned = d.stringArray(forKey: "trialOwned") ?? []
        streak = d.integer(forKey: "streak")
        soundOn = d.object(forKey: "soundOn") == nil ? true : d.bool(forKey: "soundOn")
        musicOn = d.bool(forKey: "musicOn")
        hapticsOn = d.object(forKey: "hapticsOn") == nil ? true : d.bool(forKey: "hapticsOn")
        difficulty = d.object(forKey: "difficulty") == nil ? 1 : d.integer(forKey: "difficulty")
        checkDailyReward()
    }

    var maxBest: Int { bestByMode.values.max() ?? 0 }
    func best(for mode: GameMode) -> Int { bestByMode[mode.rawValue] ?? 0 }
    var currentSkin: BirdSkin { allSkins.first { $0.id == selectedSkin } ?? allSkins[0] }
    var currentTheme: StageTheme { allThemes.first { $0.id == selectedTheme } ?? allThemes[0] }
    var difficultyGapScale: CGFloat { difficulty == 0 ? 1.22 : (difficulty == 2 ? 0.84 : 1.0) }
    var difficultySpeedScale: CGFloat { difficulty == 0 ? 0.9 : (difficulty == 2 ? 1.12 : 1.0) }

    @Published var dailyRewardMessage: String? = nil

    private func checkDailyReward() {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        let today = f.string(from: Date())
        let last = d.string(forKey: "lastPlayDay") ?? ""
        guard last != today else { return }
        let yesterday = f.string(from: Date(timeIntervalSinceNow: -86400))
        streak = (last == yesterday) ? streak + 1 : 1
        let reward = 20 + min(streak, 7) * 5
        coins += reward
        totalCoinsEarned += reward
        d.set(today, forKey: "lastPlayDay")
        dailyRewardMessage = "ログインボーナス！ \(streak)日目：\(reward)コイン もらいました"
    }

    func recordGame(mode: GameMode, score: Int, coinsEarned: Int, pipes: Int) {
        totalGames += 1
        totalPipes += pipes
        if score > best(for: mode) { bestByMode[mode.rawValue] = score }
        coins += coinsEarned
        totalCoinsEarned += coinsEarned
    }

    func grantTrialProduct(_ p: TrialProduct) {
        if !trialOwned.contains(p.id) { trialOwned.append(p.id) }
        switch p.id {
        case "gold", "robot", "rainbow":
            if !ownedSkins.contains(p.id) { ownedSkins.append(p.id) }
        case "aurora":
            if !ownedThemes.contains("aurora") { ownedThemes.append("aurora") }
        case "coinpack":
            coins += 1000; totalCoinsEarned += 1000
        case "revivepack":
            reviveTickets += 5
        case "allpack":
            for s in ["gold", "robot", "rainbow"] where !ownedSkins.contains(s) { ownedSkins.append(s) }
            if !ownedThemes.contains("aurora") { ownedThemes.append("aurora") }
            for t in ["gold", "robot", "rainbow", "aurora"] where !trialOwned.contains(t) { trialOwned.append(t) }
            coins += 2000; totalCoinsEarned += 2000
            reviveTickets += 10
        default: break
        }
    }

    // 未受け取りで達成済みの実績があれば受け取る
    func claimReadyAchievements() -> Int {
        var gained = 0
        for a in allAchievements where a.check(self) && !claimedAchievements.contains(a.id) {
            claimedAchievements.append(a.id)
            coins += a.reward
            totalCoinsEarned += a.reward
            gained += a.reward
        }
        return gained
    }
}
