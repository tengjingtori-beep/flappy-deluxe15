import Foundation
import AVFoundation

// 音源ファイルなしで音を合成する（オフライン完結・ファイル不要）
final class SoundManager {
    static let shared = SoundManager()
    private var players: [AVAudioPlayer] = []
    private var musicTimer: Timer?
    private var musicStep = 0
    private let melody: [Double] = [523.25, 659.25, 783.99, 659.25, 587.33, 659.25, 783.99, 1046.5,
                                    783.99, 659.25, 587.33, 523.25, 440.0, 523.25, 587.33, 0]

    private func wavData(freq: Double, duration: Double, volume: Float = 0.35, slide: Double = 0) -> Data {
        let sampleRate = 22050.0
        let count = Int(sampleRate * duration)
        var data = Data()
        // WAV ヘッダ
        func appendLE<T: FixedWidthInteger>(_ v: T) { var x = v.littleEndian; withUnsafeBytes(of: &x) { data.append(contentsOf: $0) } }
        let byteRate = UInt32(sampleRate) * 2
        let dataSize = UInt32(count * 2)
        data.append(contentsOf: "RIFF".utf8); appendLE(UInt32(36) + dataSize)
        data.append(contentsOf: "WAVE".utf8)
        data.append(contentsOf: "fmt ".utf8); appendLE(UInt32(16)); appendLE(UInt16(1)); appendLE(UInt16(1))
        appendLE(UInt32(sampleRate)); appendLE(byteRate); appendLE(UInt16(2)); appendLE(UInt16(16))
        data.append(contentsOf: "data".utf8); appendLE(dataSize)
        for i in 0..<count {
            let t = Double(i) / sampleRate
            let f = freq + slide * (t / duration)
            let env = 1.0 - (Double(i) / Double(count)) * 0.7
            let s = sin(2 * Double.pi * f * t) * Double(volume) * env
            appendLE(Int16(max(-1, min(1, s)) * 30000))
        }
        return data
    }

    private func play(freq: Double, duration: Double, slide: Double = 0, volume: Float = 0.35) {
        guard GameData.shared.soundOn else { return }
        do {
            let p = try AVAudioPlayer(data: wavData(freq: freq, duration: duration, volume: volume, slide: slide))
            p.prepareToPlay(); p.play()
            players.append(p)
            if players.count > 8 { players.removeFirst(players.count - 8) }
        } catch { /* 音が出なくてもゲームは続ける */ }
    }

    func flap()  { play(freq: 620, duration: 0.09, slide: 500) }
    func score() { play(freq: 988, duration: 0.09); DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { self.play(freq: 1319, duration: 0.14) } }
    func coin()  { play(freq: 1568, duration: 0.07); DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { self.play(freq: 2093, duration: 0.1) } }
    func power() { play(freq: 523, duration: 0.08, slide: 900) }
    func hit()   { play(freq: 160, duration: 0.3, slide: -80, volume: 0.5) }
    func die()   { play(freq: 700, duration: 0.5, slide: -600) }
    func click() { play(freq: 840, duration: 0.05, volume: 0.2) }
    func buy()   { play(freq: 1047, duration: 0.1); DispatchQueue.main.asyncAfter(deadline: .now() + 0.09) { self.play(freq: 1568, duration: 0.16) } }

    func startMusic() {
        stopMusic()
        guard GameData.shared.musicOn else { return }
        musicTimer = Timer.scheduledTimer(withTimeInterval: 0.24, repeats: true) { [weak self] _ in
            guard let self = self, GameData.shared.musicOn else { return }
            let f = self.melody[self.musicStep % self.melody.count]
            self.musicStep += 1
            if f > 0 { self.play(freq: f, duration: 0.22, volume: 0.10) }
        }
    }
    func stopMusic() { musicTimer?.invalidate(); musicTimer = nil }
}
